key = "grape"
for character in key:
    ascii_value = ord(character)
    print("grape", ascii_value)

key = "apple"
for character in key:
    ascii_value = ord(character)
    print("apple", ascii_value)

key = "banana"
for character in key:
    ascii_value = ord(character)
    print("banana", ascii_value)

key = "orange"
for character in key:
    ascii_value = ord(character)
    print("orange", ascii_value)

key = "kiwi"
for character in key:
    ascii_value = ord(character)
    print("kiwi", ascii_value)