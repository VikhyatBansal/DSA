public class asciivalue {
    public static void main(String[] args) {
        String str = "grape";
        for (int i = 0; i < str.length(); i++) {
            int ascii_value = (int) str.charAt(i);
            System.out.println("Character " + str.charAt(i) + " has ASCII value of " + ascii_value);
        }
        // String str = "apple";
        // for (int i = 0; i < str.length(); i++) {
        //     int ascii_value = (int) str.charAt(i);
        //     System.out.println("Character " + str.charAt(i) + " has ASCII value of " + ascii_value);
        // }
        // String str = "banana";
        // for (int i = 0; i < str.length(); i++) {
        //     int ascii_value = (int) str.charAt(i);
        //     System.out.println("Character " + str.charAt(i) + " has ASCII value of " + ascii_value);
        // }
        // String str = "orange";
        // for (int i = 0; i < str.length(); i++) {
        //     int ascii_value = (int) str.charAt(i);
        //     System.out.println("Character " + str.charAt(i) + " has ASCII value of " + ascii_value);
        // }
        // String str = "kiwi";
        // for (int i = 0; i < str.length(); i++) {
        //     int ascii_value = (int) str.charAt(i);
        //     System.out.println("Character " + str.charAt(i) + " has ASCII value of " + ascii_value);
        // }

    }
}
