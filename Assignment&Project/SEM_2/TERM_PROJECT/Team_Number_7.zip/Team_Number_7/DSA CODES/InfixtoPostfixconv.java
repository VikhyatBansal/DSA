package PROJECT;

//import java.util.Scanner;
import java.util.*;

public class InfixtoPostfixConv {

    class Stack1 {

        int top;
        char[] array;
        int length;

        Stack1(int a) {

            length = a;
            array = new char[length];
            top = -1;
        }

        // checking whether stack is full or not
        public boolean isFull() {
            return top == length - 1;
        }

        // checking whether stack is empty or not
        public boolean isEmpty() {
            return top == -1;
        }

        // pushing elements on to the stack
        public void push(char num) {
            if (isFull()) {
                System.out.println("STACK IS FULL");
                System.exit(0);
            }
            top = top + 1;
            array[top] = num;
        }

        // popping elements from the stack
        public char pop() {
            if (isEmpty()) {
                System.out.println("STACK IS EMPTY");
                System.exit(0);
            }
            top = top - 1;
            char[] temparr = new char[array.length - 1];
            for (int i = 0; i < temparr.length; i++) {
                temparr[i] = array[i];
            }
            array = temparr;
            length--;
            return array[top + 1];
        }

        // to return the top element of the stack
        public void peek_operation() {
            System.out.println("ELEMENT AT THE TOP OF STACK IS :  ");
            System.out.println(array[length - 1]);
        }

        // TO DISPLAY THE ENTIRE STACK
        public void display() {

            for (int i = 0; i <= top; i++) {
                System.out.println(array[i]);
            }
        }
    }

    Stack1 d;
    String postfix = "";

    public String infixToPostfix(String s) {

        d = new Stack1(s.length());

        char[] ch = new char[s.length()];
        char temp;

        for (int i = 0; i < s.length(); i++) {
            temp = s.charAt(i);
            ch[i] = temp;
        }

        for (char c : ch) {
            if (c != '+' && c != '-' && c != '*' && c != '/' && c != '(' && c != ')') {
                postfix = postfix + c;
            } else if (c == '(') {
                d.push(c);
            } else if (c == ')') {
                while (!d.isEmpty()) {
                    char t = d.pop();
                    if (t != '(') {
                        postfix = postfix + t;
                    } else {
                        break;
                    }
                }
            } else if (c == '+' || c == '-' || c == '*' || c == '/') {
                if (d.isEmpty()) {
                    d.push(c);
                } else {
                    while (!d.isEmpty()) {
                        char t = d.pop();
                        if (t == '(') {
                            d.push(t);
                            break;
                        } else if (t == '+' || t == '-' || t == '*' || t == '/') {
                            if (getPriority(t) < getPriority(c)) {
                                d.push(t);
                                break;
                            } else {
                                postfix = postfix + t;
                            }
                        }
                    }
                    d.push(c);
                }
            }
        }

        while (!d.isEmpty()) {
            postfix = postfix + d.pop();
        }
        return postfix;
    }

    public int getPriority(char c) {
        if (c == '+' || c == '-') {
            return 1;
        } else {
            return 2;
        }
    }

    public static void main(String[] args) {
        InfixtoPostfixConv a = new InfixtoPostfixConv();

        String s;
        System.out.println("Enter the infix expression: ");
        Scanner sc = new Scanner(System.in);
        s = sc.nextLine();

        String s1 = a.infixToPostfix(s);
        System.out.println(s1);
    }
}