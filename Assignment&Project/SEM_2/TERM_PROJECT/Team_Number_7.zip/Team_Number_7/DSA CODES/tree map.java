// Java program to demonstrate some basic functions
// of TreeMap and TreeSet

import java.util.*;
import java.io.*;

class TSM {
	public static void main(String[] args) {

		TreeSet<Integer> st = new TreeSet<>();
		st.add(4);
		st.add(5);
		st.add(5);
		st.add(4);
		st.add(4);

		TreeMap<Integer, Integer> tm = new TreeMap<>();
		tm.put(1, 5);
		tm.put(2, 6);
		tm.put(3, 6);
		tm.put(4, 3);

		System.out.println(st);
		System.out.println(tm);

	}
}
